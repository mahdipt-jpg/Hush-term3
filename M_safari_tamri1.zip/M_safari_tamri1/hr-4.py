n = int(input().strip())
  for i in range(n):
    print(i * i)
