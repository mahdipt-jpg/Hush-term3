a = int(input().strip())
b = int(input().strip())

print(a + b)
print(a - b)
print(a * b)
